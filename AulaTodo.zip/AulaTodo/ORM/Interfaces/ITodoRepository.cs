﻿using System;
using System.Collections.Generic;
using System.Text;
using Entities;

namespace ORM.Interfaces
{
    public interface ITodoRepository : IRepository<ToDo>
    {

    }
}
